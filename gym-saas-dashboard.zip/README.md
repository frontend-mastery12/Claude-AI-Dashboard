# PulseFit — Gym Operations Dashboard

Premium dark-mode Fitness/Gym SaaS dashboard built with React (Vite), Tailwind CSS,
React Router DOM, and Recharts, following the architecture in `context.md`.

## Getting started

```bash
npm install
npm run dev       # start the dev server (http://localhost:5173)
npm run build     # production build to dist/
npm run preview   # preview the production build
```

## Structure

- `src/app` — Sidebar, Topbar, and the MainLayout that wraps every route.
- `src/components/ui` — Card, Button, Table, Badge, ChartPanel, MetricTile, PageShell.
- `src/components/shared` — SearchBar.
- `src/pages/Dashboard` — hero vitals, calorie/macro ring, heart rate chart, goal
  building list, recommended activity list, trainer showcase.
- `src/pages/Transactions` — KPI summary, filter toolbar, bulk actions, delete
  confirmation modal + undo, paginated table. All transaction state is owned by
  `Transactions.jsx` and passed down via props (`onToggleSelect`, `onDelete`, etc.).
- `src/pages/Analytics` — KPI row, revenue vs. expenses line chart, class
  popularity donut chart, secondary operations comparison row.
- `src/utils/cn.js` — `clsx` + `tailwind-merge` class helper.

## Design tokens

Canvas `#0A0A0A`, surface `#111111`, accent `#7CFF6B`, warning `#F5B700`, neutral
`#9CA3AF` — configured in `tailwind.config.js` and used throughout via the custom
component classes in `src/index.css` (`.panel`, `.metric-card`, `.nav-item`, `.table-row`).
